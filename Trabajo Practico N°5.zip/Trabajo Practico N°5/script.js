document.addEventListener("DOMContentLoaded", async () => {
    const url = "https://apidemo.geoeducacion.com.ar/api/testing/pearson/1";
    const response = await fetch(url);
    const data = (await response.json()).data[0].valores;

    // Funcion para calcular el coeficiente de Pearson
    function calcularPearson(x, y) {
        const n = x.length;
        const sumX = x.reduce((a, b) => a + b, 0);
        const sumY = y.reduce((a, b) => a + b, 0);
        const sumXY = x.map((xi, i) => xi * y[i]).reduce((a, b) => a + b, 0);
        const sumX2 = x.map(xi => xi ** 2).reduce((a, b) => a + b, 0);
        const sumY2 = y.map(yi => yi ** 2).reduce((a, b) => a + b, 0);

        return (
            (n * sumXY - sumX * sumY) /
            Math.sqrt((n * sumX2 - sumX ** 2) * (n * sumY2 - sumY ** 2))
        );
    }

    // Extraer datos 
    const variables = {
        presion: data.map(d => d.presion),
        temperatura: data.map(d => d.temperatura),
        humedad: data.map(d => d.humedad),
        viento: data.map(d => d.viento)
    };

    // Calcular y mostrar coeficientes
    const paresVariables = [
        ["Presión", "Temperatura", variables.presion, variables.temperatura],
        ["Presión", "Humedad", variables.presion, variables.humedad],
        ["Presión", "Velocidad del viento", variables.presion, variables.viento],
        ["Temperatura", "Humedad", variables.temperatura, variables.humedad],
        ["Temperatura", "Velocidad del viento", variables.temperatura, variables.viento],
        ["Humedad", "Velocidad del viento", variables.humedad, variables.viento]
    ];

    const container = document.getElementById("container");
    paresVariables.forEach(([var1, var2, x, y]) => {
        const coeficiente = calcularPearson(x, y).toFixed(2);
        const card = document.createElement("div");
        card.classList.add("card");
        card.innerHTML = `
            <h2>${var1} y ${var2}</h2>
            <p>Coeficiente de Pearson: ${coeficiente}</p>
            <p>${analizarCoeficiente(coeficiente)}</p>
        `;
        container.appendChild(card);
    });

    // Función para analizar el coeficiente
    function analizarCoeficiente(coef) {
        if (coef >= 0.7) {
            return "Correlación fuerte positiva. Esto indica que ambas variables tienden a aumentar juntas, mostrando una relación lineal fuerte.";
        }
        if (coef > 0 && coef < 0.5) {
            return "Correlación positiva moderada. Las variables tienen una relación positiva, pero con cierta variabilidad en sus comportamientos.";
        }
        if (coef < 0 && coef > - 0.5) {
            return "Correlación negativa moderada. A medida que una variable aumenta, la otra tiende a disminuir, aunque la relación no es muy fuerte.";
        }
        if (coef < -0.5 && coef > -0.8) {
            return "Correlación negativa fuerte. Esto indica una fuerte correlación negativa, donde una variable aumenta mientrasla otra disminuye.";
        }
        return "No hay correlación lineal significativa entre las variables";
    }
});